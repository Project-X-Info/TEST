package datamanagement;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.Element;

import graph.Node;

public class Read {
	
	public static Node[] readNodes(String filename) {
		BufferedReader br = null;
		FileReader fr = null;
		Document document = null;
		Node[] nodeArray=null;

		try {
			fr = new FileReader(filename);
			br = new BufferedReader(fr);
			br.readLine();
			
			File file = new File("Roads_Munich_Route_Node.gml");
			document = new SAXBuilder().build(file);
			
			br.close();
			fr.close();
		} catch (JDOMException | IOException e) {
			e.printStackTrace();
		}
		
		Element root = document.getRootElement();
		//System.out.println(root.getName());
		List<Element> children = root.getChildren();
		System.out.println(children.size());
		int counter=0;
		for (int i = 0; i < children.size(); i++) {
			if (children.get(i).getName().equals("featureMember")) {
				counter++;
			}
		}
		System.out.println(counter);
		
		
		
		
		
		
		
		return nodeArray;

	}
}
