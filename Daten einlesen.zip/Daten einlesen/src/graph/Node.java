package graph;

public class Node {
	private double y;
	private double x;
	// Index in Adjazenzmatrix (von 0 weg)
	private int nodeId;
	// Indikator, ob besucht
	private boolean besucht;
	//Indikator f�r Zugeh�rigkeit zu Zusammenhangskomponente
	private int markierung;

	public Node(int nodeId, double y, double x) {
		this.y = y;
		this.x = x;
		this.nodeId = nodeId;
		besucht = false;
		markierung = 0;
	}

	/*public double getlon() {
		return lon;
	}

	public double getlat() {
		return lat;
	}

	public int getnodeID() {
		return nodeId;
	}

	public void setBesucht(Boolean besucht) {
		this.besucht = besucht;
	}

	public Boolean getBesucht() {
		return besucht;
	}

	public void setMarkierung(int markierung) {
		this.markierung = markierung;
	}

	public int getMarkierung() {
		return markierung;
	}*/

}
