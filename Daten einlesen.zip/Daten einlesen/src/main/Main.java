package main;

import datamanagement.Read;

public class Main {

	public static void main(String[] args) {
		Read read = new Read();
		read.readNodes("Roads_Munich_Route_Node.gml");

	}

}
